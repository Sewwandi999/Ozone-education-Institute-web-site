<?php
session_start(); 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ozone Education Institute</title>
    <link rel="stylesheet" href="css/home.css"> 
    <style type="text/css">
        body{
box-sizing: border-box;
    
.header .container {
    display: flex;
    align-items: center; 
    background-color: black;

}

.header .container button{
    margin-left: 100px;
    width: 15%;
    padding: 10px;
    background-color:rgba(0, 0, 0, 0.9);
    color: #39d5ff;
    border: 2px solid #39d5ff;
    font-size: 18px;
    font-weight: bold;
}
.header .container button:hover{
    color: darkgray;
}


.header .container .logo {
    margin-right: 20px; 
}

/* Styling the text */
.header .container p {
    margin: 0;
    font-size: 1.5rem; 
    font-weight: bold;
    color: #39d5ff;
    font-size: 80px; 
    text-align: center;
    margin-left: 25px;
}

.navbar{
    
    
    justify-content: space-between;
    background-color: black; 
    border-bottom: 5px solid #39d5ff; 
    border-top: 1px solid #39d5ff;
    align-content: center;
}
    

.container, .navbar {
            margin: 0px;
            padding: 0px;
            color: white;
            font-weight: bold;
            font-size: 20px;
        }
.navbar li a{
    text-decoration: none;
    color: #39d5ff; 
    font-weight: bold;
    padding: 5px 10px;
    transition: color 0.3s ease;
    border-right: 1px solid #39d5ff;
    border-left: 1px solid #39d5ff;
}
.navbar li a:hover {
    color: darkred; 
}


* {box-sizing:border-box}
.slideshow-container {
  width: 75%;
  height: 35%;
  justify-content: center;
  align-items: center;
  margin-left: 180px;
}

/* Hide the images by default */
.mySlides {
  display: none;
}

/* Next & previous buttons */
.prev, .next {
  cursor: pointer;
  position: absolute;
  top: 50%;
  width: auto;
  margin-top: -22px;
  padding: 16px;
  color: white;
  font-weight: bold;
  font-size: 18px;
  transition: 0.6s ease;
  border-radius: 0 3px 3px 0;
  user-select: none;
}

/* Position the "next button" to the right */
.next {
  right: 0;
  border-radius: 3px 0 0 3px;
}

/* On hover, add a black background color with a little bit see-through */
.prev:hover, .next:hover {
  background-color: rgba(0,0,0,0.8);
}

/* Caption text */
.text {
  color: #f2f2f2;
  font-size: 15px;
  padding: 8px 12px;
  position: absolute;
  bottom: 8px;
  width: 100%;
  text-align: center;
}

/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  cursor: pointer;
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active, .dot:hover {
  background-color: #717171;
}

/* Fading animation */
.fade {
  animation-name: fade;
  animation-duration: 1.5s;
}

@keyframes fade {
  from {opacity: .4}
  to {opacity: 1}
}

}
    </style>
</head>
<body>

<header class="header" data-header>
    <div class="container">
        <a href="#" class="logo">
            <img src="images/Black and Blue Initials Creative Logo (2).png" width="200" height="200" alt="logo">
        </a>
        <p>Ozone Education Institute</p>
        
        
        <?php if (isset($_SESSION['username'])): ?>
    <button onclick="window.location.href='logout.php'">
        <img src="images/graduating-student.png" width="25" height="25"> <?php echo htmlspecialchars($_SESSION['username']); ?>/Logout
    </button>
<?php else: ?>
    <button onclick="window.location.href='login.php'">
        <img src="images/graduating-student.png" width="30" height="30"> Log in
    </button>
<?php endif; ?>

        
    </div>

    <div class="navbar">
        <ul style="list-style-type: none; padding: 0; text-align: center;">
            <li style="display: inline; margin-right: 20px; color: red;">
                <a href="home.php">Home</a>
            </li>
            
            <li style="display: inline; margin-right: 20px;">
                <a href="..\Subject\subjects.php">Subject Stream</a>
            </li>
            <li style="display: inline; margin-right: 20px;">
                <a href="..\Time Table\time.php">Time Table</a>
            </li>
            <li style="display: inline; margin-right: 20px;">
                <a href="..\About\about.html">About</a>
            </li>
            <li style="display: inline; margin-right: 20px;">
                <a href="..\Contact\Contact.php">Contact</a>
            </li>
        </ul>
    </div>
</header>
    <div class="slideshow-container">
        <div class="mySlides fade">
            <div class="numbertext">1 / 5</div>
            <img src="images/ed.jpg" style="width:100%; height: 100%;">
            <div class="text">Unlock Your Potential</div>
        </div>

        <div class="mySlides fade">
            <div class="numbertext">2 / 5</div>
            <img src="images/learning.jpg" style="width:100%; height: 100%;">
            <div class="text">Never Stop Learning</div>
        </div>

        <div class="mySlides fade">
            <div class="numbertext">3 / 5</div>
            <img src="images/ell.jpg" style="width:100%; height: 100%;">
            <div class="text">Caption ThreeSuccess Starts Here</div>
        </div>

        <div class="mySlides fade">
            <div class="numbertext">4 / 5</div>
            <img src="images/om.jpg" style="width:100%; height: 100%;">
            <div class="text">Caption FourRise Through Learning</div>
        </div>

        <div class="mySlides fade">
            <div class="numbertext">5 / 5</div>
            <img src="images/platform.jpg" style="width:100%; height: 100%;">
            <div class="text">Believe in Your Abilities</div>
        </div>

        <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
        <a class="next" onclick="plusSlides(1)">&#10095;</a>
    </div>

    <br>

    <div style="text-align:center">
        <span class="dot" onclick="currentSlide(1)"></span>
        <span class="dot" onclick="currentSlide(2)"></span>
        <span class="dot" onclick="currentSlide(3)"></span>
    </div>


<script src="js/home.js"></script> 
</body>
</html>
