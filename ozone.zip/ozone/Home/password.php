<?php

$host = 'localhost';
$dbname = 'ozone';  
$username = 'root'; 
$password = '';     


try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die('Database connection failed: ' . $e->getMessage());
}


if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['validate_username'])) {
    $userInput = $_POST['username'];

   
    $stmt = $conn->prepare('SELECT username FROM users WHERE username = :username');
    $stmt->bindParam(':username', $userInput);
    $stmt->execute();

    
    if ($stmt->rowCount() > 0) {
        echo '<script>alert("You can modify the password.");</script>';
        
       
    } else {
        echo '<script>alert("Username is invalid.");</script>';
       
    }
}


if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['password'])) {
    $username = $_POST['username'];
    $newPassword = $_POST['password'];

    
    $stmt = $conn->prepare('UPDATE users SET password = :password WHERE username = :username');
    $stmt->bindParam(':password', $newPassword); // No hashing
    $stmt->bindParam(':username', $username);

    if ($stmt->execute()) {
        echo '<script>alert("Password updated successfully.");</script>';
        header("Location: login.php");
    } else {
        echo '<script>alert("Error updating password.");</script>';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Password Reset</title>
    <style type="text/css">
        body {
            background-color: rgba(0, 0, 0, 0.9);
            background: linear-gradient(to right,#e2e2e2);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            font-family: Arial, sans-serif;
        


        .login-container {
            background-color: black;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            width: 400px;
            text-align: center;
        }


        .login-container h2 {
            margin-bottom: 20px;
            color: #39d5ff;
            font-size: 40px;
            margin-top: 0px;
        }


        .input-group {
            margin-bottom: 15px;
            text-align: left;
        }

        .input-group label {
            display: block;
            margin-bottom: 5px;
            color: white;
            font-weight: bold;
        }

        .input-group input {
            color: white;
            width: 100%;
            padding: 8px;
            border-radius: 4px;
            border: 2px solid #ddd;
            box-sizing: border-box;
            font-size: 14px;
            background-color: transparent;
        }

        .btn {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
        }

        .btn:hover {
            background-color: #0056b3;
        }


        .error-message {
            color: red;
            margin-top: 10px;
            display: none;
        }
    }

    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-illustration">
            <img src="images/Black and Blue Initials Creative Logo (2).png" width="200" height="200" alt="Login Illustration">
        </div>
        <div class="login-form">
            <h2>Reset Password</h2>
            <form id="resetForm" action="password.php" method="post">
                <div class="input-group">
                    <label for="username">Enter the Username.</label>
                    <input type="text" id="username" name="username" required>
                </div>
                <div class="input-group">
                    <button type="button" name="validate_username" onclick="validateUsername()">Username Validation</button>
                </div>
                <div class="input-group">
                    <label for="password">Enter the new Password</label>
                    <input type="password" id="password" name="password">
                </div>
                <div class="input-group">
                    <label for="rPassword">Re-Enter The Password</label>
                    <input type="password" id="rPassword" name="rPassword">
                </div>
                <div class="input-group">
                    <button type="button" onclick="passwordConfirm()">Confirm Password</button>
                </div>
                <button type="submit" class="reg-btn">Done</button>
            </form>
        </div>
    </div>

    <script>
        function validateUsername() {
    const username = document.getElementById('username').value;

    if (username === "") {
        alert("Please enter a username.");
        return;
    }

    // Dynamically create a form to submit username validation
    const form = document.createElement('form');  // Create a form element
    form.method = 'POST';
    form.action = 'password.php';

    // Create a hidden input to send the validation flag
    const input = document.createElement('input');
    input.type = 'hidden';
    input.name = 'validate_username';  
    input.value = '1';  
    form.appendChild(input);

    // Create a hidden input for the username
    const usernameInput = document.createElement('input');
    usernameInput.type = 'hidden';
    usernameInput.name = 'username';
    usernameInput.value = username;
    form.appendChild(usernameInput);

    // Append the form to the body and submit it
    document.body.appendChild(form);
    form.submit();
}


        function passwordConfirm() {
            const password = document.getElementById("password").value;
            const rPassword = document.getElementById("rPassword").value;

            if (password === "" || rPassword === "") {
                alert("Please fill out both password fields.");
                return false;
            }

            if (password === rPassword) {
                alert("Passwords match!");
                document.getElementById('password').disabled = false;
                document.getElementById('rPassword').disabled = false;
            } else {
                alert("Passwords do not match!");
            }
        }
    </script>
</body>
</html>
