<?php
session_start();

$servername = "localhost";
$db_username = "root";  
$db_password = "";      
$dbname = "ozone";

$conn = new mysqli($servername, $db_username, $db_password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $input_username = $_POST['username'];
    $input_password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $input_username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();

        // Directly compare the input password with the stored password
        if ($input_password === $row['password']) { // Modify this line
            $_SESSION['username'] = $input_username;
            $_SESSION['login_success'] = "Login successful! Welcome, " . $input_username;
            header("Location: home.php");
            exit();
        } else {
            echo "<script>alert('Invalid Password. Please Try Again!');</script>";
        }
    } else {
        echo "<script>alert('Invalid Username. Please Try Again!');</script>";
    }
}

$conn->close();
?>




 <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <style type="text/css">
        body {
            background-color: rgba(0, 0, 0, 0.9);
            background: linear-gradient(to right,#e2e2e2);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            font-family: Arial, sans-serif;
        


        .login-container {
            background-color: black;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            width: 400px;
            text-align: center;
        }


        .login-container h2 {
            margin-bottom: 20px;
            color: #39d5ff;
            font-size: 40px;
            margin-top: 0px;
        }


        .input-group {
            margin-bottom: 15px;
            text-align: left;
        }

        .input-group label {
            display: block;
            margin-bottom: 5px;
            color: white;
            font-weight: bold;
        }

        .input-group input {
            color: white;
            width: 100%;
            padding: 8px;
            border-radius: 4px;
            border: 2px solid #ddd;
            box-sizing: border-box;
            font-size: 14px;
            background-color: transparent;
        }

        .btn {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
        }

        .btn:hover {
            background-color: #0056b3;
        }


        .error-message {
            color: red;
            margin-top: 10px;
            display: none;
        }
    }

    </style>
    
</head>
<body>
    <div class="login-container">
        <div class="login-illustration">
            <img src="images/Black and Blue Initials Creative Logo (2).png" width="200" height="200" alt="Login Illustration">
        </div>
        <div class="login-form">
            <h2>Log In</h2>
            <form id="loginForm" action="login.php" method="post">
                <div class="input-group">
                    <i class="fas fa-user"></i>
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" required>
                </div>
                <div class="input-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <div class="input-group remember-me">
                    <label for="rememberMe">Remember me</label>
                    <input type="checkbox" id="rememberMe">
                </div>
                <button type="submit" class="login-btn">Log In</button>
                <div class="links">
                    <a href="password.php">Forgot your password?</a>
                    <a href="register.php">Register</a>
                </div>
            </form>
        </div>
    </div>
    <script>
        document.getElementById("loginForm").addEventListener("submit", function(event) {
        const username = document.getElementById("username").value;
        const password = document.getElementById("password").value;

        if (username === "" || password === "") {
        alert("Please fill in both username and password fields.");
        event.preventDefault(); 
    }
});

    </script>
</body>
</html>
