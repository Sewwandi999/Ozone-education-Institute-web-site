<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ozone";  

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Process the form data
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $school = mysqli_real_escape_string($conn, $_POST['school']);
    $year = mysqli_real_escape_string($conn, $_POST['year']);
    $contact = mysqli_real_escape_string($conn, $_POST['contact']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    
    $rPassword = mysqli_real_escape_string($conn, $_POST['rPassword']);

    if ($password !== $rPassword) {
        echo "<script>alert('Passwords do not match!');</script>";
    } else {



        $sql = "INSERT INTO users (name, address, school, year, contact, username, password) 
                VALUES ('$name', '$address', '$school', '$year', '$contact', '$username', '$password')";

        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Registration successful!');</script>";
            header("Location: home.php");
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
            header("Location: register.php");
        }
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <style type="text/css">
        body {
    background-color: rgba(0, 0, 0, 0.9);
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
    font-family: Arial, sans-serif;
}


.login-container {
    background-color: black;
    padding: 15px;
    border-radius: 8px;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    width: 500px;
    text-align: center;
}


.login-container h2 {
    margin-bottom: 20px;
    color: #39d5ff;
    font-size: px;
    margin-top: 0px;

}


.input-group {
    margin-bottom: 10px;
    text-align: left;
}

.input-group label {
    display: block;
    margin-bottom: 5px;
    color: white;
    font-weight: bold;
}

.input-group input {
    color: white;
    width: 75%;
    padding: 6px;
    border-radius: 4px;
    border: 2px solid #ddd;
    box-sizing: border-box;
    font-size: 10px;
    background-color: transparent;
    margin-left: 40px;
}

.btn {
    width: 100%;
    padding: 8px;
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 4px;
    font-size: 12px;
    cursor: pointer;
    margin-left: 20px;
}

.btn:hover {
    background-color: #0056b3;
}


.error-message {
    color: red;
    margin-top: 10px;
    display: none;
}

    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-illustration">
            <img src="images/Black and Blue Initials Creative Logo (2).png" width="150" height="150" alt="Login Illustration">
        </div>
        <div class="login-form">
            <h2>Register</h2>
            <form id="regForm" action="register.php" method="post">
                <div class="input-group">
                    <label for="name">Name</label>
                    <input type="text" id="name" name="name" required>
                </div>
                <div class="input-group">
                    <label for="address">Address</label>
                    <input type="text" id="address" name="address" required>
                </div>
                <div class="input-group">
                    <label for="school">School</label>
                    <input type="text" id="school" name="school" required>
                </div>
                <div class="input-group">
                    <label for="year">A/L Year</label>
                    <input type="text" id="year" name="year" required>
                </div>
                <div class="input-group">
                    <label for="contact">Contact</label>
                    <input type="text" id="contact" name="contact" required>
                </div>
                <div class="input-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" required>
                </div>
                <div class="input-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <div class="input-group">
                    <label for="rPassword">Re-Enter The Password</label>
                    <input type="password" id="rPassword" name="rPassword" required>
                </div>
                <div class="input-group">
                    <button type="button" onclick="passwordConfirm()">Confirm Password</button>
                </div>
                <button type="submit" class="reg-btn">Register</button>
            </form>
        </div>
    </div>
    <script>
        function passwordConfirm() {
    const password = document.getElementById("password").value;
    const rPassword = document.getElementById("rPassword").value;

   
    if (password === "" || rPassword === "") {
        alert("Please fill out both password fields.");
        return false;
    }

  
    if (password === rPassword) {
        alert("Passwords match!");
    } else {
        alert("Passwords do not match!");
    }
}


document.getElementById("regForm").addEventListener("submit", function(event) {
    const password = document.getElementById("password").value;
    const rPassword = document.getElementById("rPassword").value;


    if (password !== rPassword) {
        alert("Passwords do not match!");
        event.preventDefault(); 
    }
});

    </script>
</body>
</html>
