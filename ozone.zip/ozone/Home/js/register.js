function passwordConfirm() {
    const password = document.getElementById("password").value;
    const rPassword = document.getElementById("rPassword").value;

   
    if (password === "" || rPassword === "") {
        alert("Please fill out both password fields.");
        return false;
    }

  
    if (password === rPassword) {
        alert("Passwords match!");
    } else {
        alert("Passwords do not match!");
    }
}


document.getElementById("regForm").addEventListener("submit", function(event) {
    const password = document.getElementById("password").value;
    const rPassword = document.getElementById("rPassword").value;


    if (password !== rPassword) {
        alert("Passwords do not match!");
        event.preventDefault(); 
    }
});
