<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ozone";  

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Process the form data
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $school = mysqli_real_escape_string($conn, $_POST['school']);
    $year = mysqli_real_escape_string($conn, $_POST['year']);
    $contact = mysqli_real_escape_string($conn, $_POST['contact']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    
    $rPassword = mysqli_real_escape_string($conn, $_POST['rPassword']);

    if ($password !== $rPassword) {
        echo "<script>alert('Passwords do not match!');</script>";
    } else {



        $sql = "INSERT INTO users (name, address, school, year, contact, username, password) 
                VALUES ('$name', '$address', '$school', '$year', '$contact', '$username', '$password')";

        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Registration successful!');</script>";
            header("Location: home.php");
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}

$conn->close();
?>
