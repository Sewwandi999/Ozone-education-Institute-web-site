<?php

	$con = mysqli_connect("localhost","root","","ozone");

	if(!$con){
		die("Connection Error");
	}

?>