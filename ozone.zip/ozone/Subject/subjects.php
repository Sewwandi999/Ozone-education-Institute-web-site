<?php
session_start(); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Higher Education Center - Classes</title>
    <link rel="stylesheet" href="..\Subject\css\subjects.css">
    <style type="text/css">
        body {
    margin: 0;
    padding: 0;
    font-family: Arial, sans-serif;
    box-sizing: border-box;
}


.header .container {
    display: flex;
    align-items: center;
    background-color: black;
}

.header .container button {
    margin-left: 100px;
    width: 10%;
    padding: 10px;
    background-color: rgba(0, 0, 0, 0.9);
    color: #39d5ff;
    border: 2px solid #39d5ff;
    font-size: 20px;
    font-weight: bold;
}

.header .container button:hover {
    color: darkgray;
}

.header .container .logo {
    margin-right: 20px;
}

/* Styling the text */
.header .container p {
    margin: 0;
    font-size: 80px;
    font-weight: bold;
    color: #39d5ff;
    text-align: center;
    margin-left: 25px;
}

.navbar {
    justify-content: space-between;
    background-color: black;
    border-bottom: 5px solid #39d5ff;
    border-top: 1px solid #39d5ff;
    align-content: center;
}

.navbar li a {
    text-decoration: none;
    color: #39d5ff;
    font-weight: bold;
    padding: 5px 10px;
    transition: color 0.3s ease;
    border-right: 1px solid #39d5ff;
    border-left: 1px solid #39d5ff;
}

.navbar li a:hover {
    color: darkred;
}


.banner {
    text-align: center;
    padding: 50px 0;
    background-image: url('images/ST.jpg');
    background-size: cover;
    background-repeat: no-repeat;
    background-position: center;
    color: blue;
    font-family: sans-serif;
    font-weight: bold;
    text-shadow: -1px -1px 0px black, 1px -1px 0px black, -1px 1px 0px black, 1px 1px 0px black;
}


.banner h1 {
    font-size: 3rem;
    font-family: monospace;
    color: #39d5ff;
}

.banner button {
    margin-left: 50px;
    margin-right: 50px;
    width: 70%;
    border-radius: 8px;
    padding: 30px;
    background-color: rgba(0, 0, 0, 0.9);
    color: #39d5ff;
    border: 2px solid #39d5ff;
    font-size: 20px;
    font-weight: bold;

}

/* Subject Slider Styling */
.subjects-slider {
    overflow: hidden;
    width: 100%;
    background-color: #f4f4f4;
    padding: 20px 0;
}

.slider-container {
    display: flex;
    justify-content: space-around;
    width: max-content;
    animation: slide 15s linear infinite;
}

.slide {
    min-width: 200px;
    text-align: center;
}

.slide img {
    width: 100px;
    margin-bottom: 10px;
}

.slide span {
    display: block;
    font-size: 1rem;
    color: black;
}

/* Animation Keyframes */
@keyframes slide {
    0% { transform: translateX(0); }
    100% { transform: translateX(-100%); }
}

/* Footer */
footer {
    text-align: center;
    padding: 20px;
    background-color: #333;
    color: white;
}

.highlight {
    color: red;
    font-weight: bold;
}

    </style>
</head>
<body>
    <header class="header" data-header>
        <div class="container">
        <a href="#" class="logo">
            <img src="..\Home\images\Black and Blue Initials Creative Logo (2).png" width="200" height="200" alt="logo">
        </a>
        <p>Ozone Education Institute</p>
        <?php if (isset($_SESSION['username'])): ?>"C:\xampp\htdocs\ozone\Home\images\Black and Blue Initials Creative Logo (2).png"
    <button onclick="window.location.href='logout.php'">
        <img src="images/graduating-student.png" width="25" height="25"> <?php echo htmlspecialchars($_SESSION['username']); ?>/Logout
    </button>
<?php else: ?>
    <button onclick="window.location.href='login.html'">
        <img src="images/graduating-student.png" width="30" height="30"> Log in
    </button>
<?php endif; ?>

        
    </div>

    <div class="navbar">
        <ul style="list-style-type: none; padding: 0; text-align: center;">
            <li style="display: inline; margin-right: 20px; color: red;">
                <a href="..\Home\home.php">Home</a>
            </li>
            
            <li style="display: inline; margin-right: 20px;">
                <a href="subjects.php">Subject Stream</a>
            </li>
            <li style="display: inline; margin-right: 20px;">
                <a href="..\Time Table\time.php">Time Table</a>
            </li>
            <li style="display: inline; margin-right: 20px;">
                <a href="..\About\about.html">About</a>
            </li>
            <li style="display: inline; margin-right: 20px;">
                <a href="..\Contact\Contact.php">Contact</a>
            </li>
        </ul>
    </div>
</header>

    <section class="banner">
        <h1>Our Subject Streams</h1>
        <button type="button" onclick="window.location.href='science.php'">Science</button>
        <button type="button"onclick="window.location.href='tech.php'">Technology</button>
    </section>

    <section class="subjects-slider">
        <div class="slider-container">
            <div class="slide">
                <a href="ict.html"><img src="..\Subject\images\cmath.png" alt="Combined Maths"><span>Com.Maths</span></a>
            </div>
            <div class="slide">
                <a href="engineering.html"><img src="..\Subject\images\biology.png" alt="Biology"><span>Biology</span></a>
            </div>
            <div class="slide">
                <a href="bst.html"><img src="..\Subject\images\physics.png" alt="Physics"><span>Physics</span></a>
            </div>
            <div class="slide">
                <a href="com-maths.html"><img src="..\Subject\images\chemistry.png" alt="Chemistry"><span>Chemistry </span></a>
            </div>
            <div class="slide">
                <a href="tamil.html"><img src="..\Subject\images\ict.png" alt="ICT"><span>Information & Com.Technology </span></a>
            </div>
            <div class="slide">
                <a href="sft.html"><img src="..\Subject\images\bst.png" alt="BST"><span>Bio System Technology </span></a>
            </div>
            <div class="slide">
                <a href="sft.html"><img src="..\Subject\images\et.png" alt="ET"><span>Engineering Technology </span></a>
            </div>
            <div class="slide">
                <a href="sft.html"><img src="..\Subject\images\sft.png" alt="SFT"><span>Science For Technology </span></a>
            </div>
        </div>
    </section>

    <footer>
        <p>Reserve your valuable time for the <span class="highlight">experts</span></p>
    </footer>

    <script>
        
const sliderContainer = document.querySelector('.slider-container');


let isPaused = false;
let scrollSpeed = 1; 


function moveSlider() {
    if (!isPaused) {
        sliderContainer.scrollLeft += scrollSpeed;
        if (sliderContainer.scrollLeft >= sliderContainer.scrollWidth / 2) {
            sliderContainer.scrollLeft = 0; 
        }
    }
}


sliderContainer.addEventListener('mouseenter', () => {
    isPaused = true;
});

sliderContainer.addEventListener('mouseleave', () => {
    isPaused = false;
});


setInterval(moveSlider, 20);

    </script>
</body>
</html>
