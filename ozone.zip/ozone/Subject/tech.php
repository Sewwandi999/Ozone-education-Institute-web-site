<?php

    require_once('db.php');
    $query = "select * from teachert";
    $result = mysqli_query($con,$query);

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
    <style type="text/css">
        body {
    margin: 0;
    padding: 0;
    font-family: Arial, sans-serif;
    box-sizing: border-box;
}


.header .container {
    display: flex;
    align-items: center;
    background-color: black;
}

.header .container button {
    margin-left: 100px;
    width: 10%;
    padding: 10px;
    background-color: rgba(0, 0, 0, 0.9);
    color: #39d5ff;
    border: 2px solid #39d5ff;
    font-size: 20px;
    font-weight: bold;
}

.header .container button:hover {
    color: darkgray;
}

.header .container .logo {
    margin-right: 20px;
}

/* Styling the text */
.header .container p {
    margin: 0;
    font-size: 80px;
    font-weight: bold;
    color: #39d5ff;
    text-align: center;
    margin-left: 25px;
}

.navbar {
    justify-content: space-between;
    background-color: black;
    border-bottom: 5px solid #39d5ff;
    border-top: 1px solid #39d5ff;
    align-content: center;
}

.navbar li a {
    text-decoration: none;
    color: #39d5ff;
    font-weight: bold;
    padding: 5px 10px;
    transition: color 0.3s ease;
    border-right: 1px solid #39d5ff;
    border-left: 1px solid #39d5ff;
}

.navbar li a:hover {
    color: darkred;
}

.teachers-section {
    text-align: center;
    margin: 50px auto;
}
.teachers-section h2{
    margin-top: 0;
    font-family: serif;
    font-size: 40px;

}
.teachers-section p{
    margin-top: 0;
    font-family: monospace;
    font-size: 32px;

}

.teacher-cards {
    display: flex;
    justify-content: space-around;
    margin-top: 40px;
}

.teacher-card {
    background-color: white;
    padding: 20px;
    border-radius: 10px;
    width: 200px;
    text-align: center;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    transition: transform 0.3s;
    cursor: pointer;
}
.teacher-cards p{
    font-family: serif;
    font-size: 15px;
}

.teacher-card:hover {
    transform: translateY(-10px);
}

.teacher-card img {
    width: 100%;
    border-radius: 10px;
}

/* Modal styles */
.modal {
    display: none;
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
}

.modal-content {
    background-color: #fff;
    margin: 15% auto;
    padding: 20px;
    border-radius: 10px;
    width: 50%;
    text-align: center;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

.modal-content h2 {
    margin-top: 0;
    font-family: cursive;
    font-size: 15;
}

.modal-content p {
    margin: 10px 0;
}

.close {
    color: red;
    float: right;
    font-size: 28px;
    font-weight: bold;
    cursor: pointer;
}

.close:hover {
    color: darkred;
}
.schedule-container {
    width: 80%;
    margin: 50px auto;
    overflow-x: auto;
}

.schedule-table {
    width: 100%;
    border-collapse: collapse;
    margin: 20px 0;
}

.schedule-table thead tr {
    background-color: black;
    color: #39d5ff;
    text-align: left;
}

.schedule-table th, .schedule-table td {
    padding: 12px 15px;
    border: 1px solid #ddd;
    text-align: center;
}

.schedule-table tbody tr:nth-child(even) {
    background-color: #f2f2f2;
}

.schedule-table tbody tr:hover {
    background-color: #f5f5f5;
    cursor: pointer;
}
    </style>
</head>
<body>
<header class="header" data-header>
        <div class="container">
        <a href="#" class="logo">
            <img src="..\Home\images\Black and Blue Initials Creative Logo (2).png" width="200" height="200" alt="logo">
        </a>
        <p>Ozone Education Institute</p>
        <button onclick="window.location.href='login.html'"><img src="images\graduating-student.png" width="30" height="30"> Log in</button>
        
        
    </div>
    <div class="navbar">
    <ul style="list-style-type: none; padding: 0; text-align: center;">
      <li style="display: inline; margin-right: 20px;"><a href="..\Home\home.php">Home</a></li>
      <li style="display: inline; margin-right: 20px;"><a href="subjects.php">Subject Stream</a></li>
      <li style="display: inline; margin-right: 20px;"><a href="..\Time Table\time.php">Time table</a></li>
      <li style="display: inline; margin-right: 20px;"><a href="..\About\about.html">About</a></li>
      <li style="display: inline; margin-right: 20px;"><a href="..\Contact\Contact.php">Contact</a></li>
  </ul>
</div>
    </header>
    <section class="teachers-section">
        <h2>Our Teachers</h2>
        <p>We are here to build your success with our <span class="highlight">experience...</span></p>

        <div class="teacher-cards">
            <div class="teacher-card" onclick="openModal('manjula-modal')">
                <img src="images\manjula-sanjeewa.jpg" alt="Manjula Sanjeewa">
                <h3>Manjula Sanjeewa</h3>
                <p><a href="#">BIT(UOC), MCPS, A+ Network A+</a></p>
                <p>ICT</p>
            </div>

            <div class="teacher-card" onclick="openModal('mahesh-modal')">
                <img src="images\Mahesh-Hewanayake.jpg" alt="Mahesh Hewanayaka">
                <h3>Mahesh Hewanayaka</h3>
                <p><a href="#">B.Sc, Uni. Of Kelaniya , Dip. In English Uni. Of Colombo</a></p>
                <p>SFT</p>
            </div>
    
            <div class="teacher-card" onclick="openModal('sameera-modal')">
                <img src="images\Sameera-Karunarathne.jpg" alt="Sameera Karunarathne">
                <h3>Sameera Karunarathne</h3>
                <p><a href="#">B.Sc.(M.Eng), MEA</a></p>
                <p>ET</p>
              
    </section>
    <div id="manjula-modal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeModal('manjula-modal')">&times;</span>
        <h2>Manjula Sanjeewa</h2>
        <p><strong>Qualification:</strong> BIT(UOC), MCPS, A+ Network A+</p>
        <p><strong>Subject:</strong> ICT</p>
        <p><strong>Experience:</strong> 10+ years of teaching experience.</p>
        <div class="schedule-container">
        <table class="schedule-table">
            <thead>
                <tr>
                    <th>Subject</th>
                    <th>Class</th>
                    <th>Day</th>
                    <th>From</th>
                    <th>To</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>ICT</td>
                    <td>2020 Theory</td>
                    <td>Saturday</td>
                    <td>07:00</td>
                    <td>13:00</td>
                </tr>
                <tr>
                    <td>ICT</td>
                    <td>2021 Theory</td>
                    <td>Saturday</td>
                    <td>13:00</td>
                    <td>17:30</td>
                </tr>
                <tr>
                    <td>ICT</td>
                    <td>2022 Theory</td>
                    <td>Saturday</td>
                    <td>07:00</td>
                    <td>12:00</td>
                </tr>
                <tr>
                    <td>ICT</td>
                    <td>2020 Revision</td>
                    <td>Friday</td>
                    <td>07:00</td>
                    <td>14:00</td>
                </tr>
               
            </tbody>
        </table>
    </div>


    </div>
</div>


    </div>
</div>

<!-- Modal for Mahesh Hewanayaka -->
<div id="mahesh-modal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeModal('mahesh-modal')">&times;</span>
        <h2>Mahesh Hewanayaka</h2>
        <p><strong>Qualification:</strong> B.Sc, Uni. Of Kelaniya, Dip. In English Uni. Of Colombo</p>
        <p><strong>Subject:</strong> SFT</p>
        <p><strong>Experience:</strong> 8+ years of teaching experience.</p>
<div class="schedule-containerr">
    <table class="schedule-table">
        <thead>
            <tr>
                <th>Subject</th>
                <th>Class</th>
                <th>Day</th>
                <th>From</th>
                <th>To</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>SFT</td>
                <td>2020 Theory</td>
                <td>Saturday</td>
                <td>07:30</td>
                <td>10:00</td>
            </tr>
            <tr>
                <td>SFT</td>
                <td>2021 Theory</td>
                <td>Saturday</td>
                <td>10:00</td>
                <td>12:00</td>
            </tr>
            <tr>
                <td>SFT</td>
                <td>2022 Theory</td>
                <td>Wednesday</td>
                <td>10:00</td>
                <td>12:00</td>
            </tr>
            <tr>
                <td>SFT</td>
                <td>2022 Theory</td>
                <td>Saturday</td>
                <td>12:00</td>
                <td>14:00</td>
            </tr>
            <tr>
                <td>SFT</td>
                <td>2020 Revision</td>
                <td>Wednesday</td>
                <td>08:00</td>
                <td>14:00</td>
            </tr>
            <tr>
                <td>SFT</td>
                <td>2020 Paper</td>
                <td>Wednesday</td>
                <td>14:30</td>
                <td>17:00</td>
            </tr>
        </tbody>
    </table>
</div>

</div>


</div>
<div id="sameera-modal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeModal('sameera-modal')">&times;</span>
        <h2>Mahesh Hewanayaka</h2>
        <p><strong>Qualification:</strong> B.Sc, Uni. Of Kelaniya, Dip. In English Uni. Of Colombo</p>
        <p><strong>Subject:</strong> SFT</p>
        <p><strong>Experience:</strong> 8+ years of teaching experience.</p>
          <div class="schedule-container">
                <table class="schedule-table">
                    <thead>
                        <tr>
                            <th>Subject</th>
                            <th>Class</th>
                            <th>Day</th>
                            <th>From</th>
                            <th>To</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>ET</td>
                            <td>2020 Theory</td>
                            <td>Saturday</td>
                            <td>07:30</td>
                            <td>10:00</td>
                        </tr>
                        <tr>
                            <td>ET</td>
                            <td>2021 Theory</td>
                            <td>Saturday</td>
                            <td>10:00</td>
                            <td>12:00</td>
                        </tr>
                        <tr>
                            <td>ET</td>
                            <td>2022 Theory</td>
                            <td>Wednesday</td>
                            <td>10:00</td>
                            <td>12:00</td>
                        </tr>
                        <tr>
                            <td>ET</td>
                            <td>2022 Theory</td>
                            <td>Saturday</td>
                            <td>12:00</td>
                            <td>14:00</td>
                        </tr>
                        <tr>
                            <td>ET</td>
                            <td>2020 Revision</td>
                            <td>Wednesday</td>
                            <td>08:00</td>
                            <td>14:00</td>
                        </tr>
                        <tr>
                            <td>ET</td>
                            <td>2020 Paper</td>
                            <td>Wednesday</td>
                            <td>14:30</td>
                            <td>17:00</td>
                        </tr>
                    </tbody>
                </table>
            </div>

            </div>
    </div>
</div>
<section class="teachers-section">
    <div class="schedule-container">
        <table class="schedule-table">
            <thead>
            <tr class="bg-dark text-white">
                <td>ID</td>
                <td>Teacher</td>
                <td>Subject</td>
                <td>Results in 2018</td>
                <td>Results in 2019</td>
            </tr>
        </thead>
            <tr>
                <?php

                    while($row = mysqli_fetch_assoc($result)) 
                    {
                ?>
                    <td><?php echo $row['tid'];?></td>
                    <td><?php echo $row['name'];?></td>
                    <td><?php echo $row['subject'];?></td>
                    <td><?php echo $row['result_2018'];?></td>
                    <td><?php echo $row['result_2019'];?></td>
                </tr>
                <?php

                    }

                    ?>
        </table>
    </div>
</section>
<script>
    function openModal(modalId) {
    document.getElementById(modalId).style.display = 'block';
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

window.onclick = function(event) {
    var modals = document.getElementsByClassName('modal');
    for (var i = 0; i < modals.length; i++) {
        if (event.target == modals[i]) {
            modals[i].style.display = 'none';
        }
    }
}

</script>
</body>
</html>
