
const sliderContainer = document.querySelector('.slider-container');


let isPaused = false;
let scrollSpeed = 1; 


function moveSlider() {
    if (!isPaused) {
        sliderContainer.scrollLeft += scrollSpeed;
        if (sliderContainer.scrollLeft >= sliderContainer.scrollWidth / 2) {
            sliderContainer.scrollLeft = 0; 
        }
    }
}


sliderContainer.addEventListener('mouseenter', () => {
    isPaused = true;
});

sliderContainer.addEventListener('mouseleave', () => {
    isPaused = false;
});


setInterval(moveSlider, 20);
