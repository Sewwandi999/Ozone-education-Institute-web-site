<?php
    $con=new mysqli('localhost','root','','ozone');
    if(!$con){
        die(mysqli_error($con));
    }
?>