<?php
include 'connect.php';

if (isset($_POST['submit'])) {
    // Use mysqli_real_escape_string to prevent SQL injection
    $name = mysqli_real_escape_string($con, $_POST['name']);
    $mobile = mysqli_real_escape_string($con, $_POST['mobile']);
    $message = mysqli_real_escape_string($con, $_POST['message']);

    // Prepare the SQL statement
    $sql = "INSERT INTO `contact` (name, mobile, message) VALUES ('$name', '$mobile', '$message')";
    $result = mysqli_query($con, $sql);

    if ($result) {
        header('Location: Contact.php');
    } else {
        die(mysqli_error($con));
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us </title>
   
    <style type="text/css">
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

body {
    background-color: #f4f4f4;
    box-sizing: border-box;
}

.header .container {
      display: flex;
      align-items: center; 
      background-color: black;

    }

    .header .container button{
      margin-left: 100px;
      width: 10%;
      padding: 10px;
      background-color:rgba(0, 0, 0, 0.9);
      color: #39d5ff;
      border: 2px solid #39d5ff;
      font-size: 20px;
      font-weight: bold;
    }
    .header .container button:hover{
      color: darkgray;
    }


    .header .container .logo {
      margin-right: 20px; 
    }


    .header .container p {
      margin: 0;
      font-size: 1.5rem; 
      font-weight: bold;
      color: #39d5ff;
      font-size: 80px; 
      text-align: center;
      margin-left: 25px;
  }


    .navbar{
      justify-content: space-between;
      background-color: black; 
      border-bottom: 5px solid #39d5ff; 
      border-top: 1px solid #39d5ff;
      align-content: center;
  }
  
    .container, .navbar {
            margin: 0px;
            padding: 0px;
            color: white;
            font-weight: bold;
            font-size: 20px;
        }
    .navbar li a{
    text-decoration: none;
    color: #39d5ff; 
    font-weight: bold;
    padding: 5px 10px;
    transition: color 0.3s ease;
    border-right: 1px solid #39d5ff;
    border-left: 1px solid #39d5ff;
  }
    .navbar li a:hover {
      color: darkred; 
  }

.logo {
    font-size: 24px;
}

.nav-links a {
    color: #fff;
    margin: 0 15px;
    text-decoration: none;
    font-size: 16px;
}

.profile-icon img {
    width: 30px;
    height: 30px;
    border-radius: 50%;
}

.contact-section {
    display: flex;
    justify-content: space-between;
    padding: 40px;
    background-color: #fff;
    margin: 20px auto;
    max-width: 1000px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.contact-info {
    width: 40%;
}

.contact-info h2 {
    font-size: 28px;
    margin-bottom: 20px;
}

.contact-info p {
    font-size: 18px;
    line-height: 1.6;
}

.contact-form {
    width: 50%;
}

.contact-form form {
    display: flex;
    flex-direction: column;
}

.contact-form label {
    font-size: 16px;
    margin-bottom: 10px;
}

.contact-form input,
.contact-form textarea {
    padding: 10px;
    font-size: 16px;
    margin-bottom: 20px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

.contact-form textarea {
    resize: vertical;
    height: 150px;
}

button {
    padding: 10px 15px;
    font-size: 16px;
    background-color: #333;
    color: #fff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

button:hover {
    background-color: #555;
}

.vertical-line {
    position: relative;
    width: 4px;
    right:2vw;
    background-color: #333; 
    height: 340px; 
    margin: 0 20px; 
}

.styled-table{
    width:50vw;

}

.styled-table tr td{
    position: relative;
    padding: 10px;
    text-align: center;
}
#timmer {
    color: #FFF;
    display: flex;
    gap: 0.5px;
    font-size: 15px;
    color: white;
    background-color: black;
}

.alltime {
    display: flex;
    justify-content: center;
    align-items: center;
    width: 60px;
    height: 60px;
    color: white;
    background-color: black;
}

footer {
    position:relative;
    background-color: #333;
    bottom: -3vh;
    color: #fff;
    text-align: center;
    padding: 10px 0;
    margin-top: 40px;
}


    </style>
</head>
<body>
   <header class="header" data-header>
    <div class="container">
        <a href="#" class="logo">
            <img src="..\Home\images\Black and Blue Initials Creative Logo (2).png" width="200" height="200" alt="logo">
        </a>
        <p>Ozone Education Institute</p>
        
        
        <?php if (isset($_SESSION['username'])): ?>
    <button onclick="window.location.href='logout.php'">
        <img src="graduating-student.png" width="25" height="25"> <?php echo htmlspecialchars($_SESSION['username']); ?>/Logout
    </button>
<?php else: ?>
    <button onclick="window.location.href='login.html'">
        <img src="graduating-student.png" width="30" height="30"> Log in
    </button>
<?php endif; ?>

        
    </div>

    <div class="navbar">
        <ul style="list-style-type: none; padding: 0; text-align: center;">
            <li style="display: inline; margin-right: 20px; color: red;">
                <a href="..\Home\home.php">Home</a>
            </li>
            
            <li style="display: inline; margin-right: 20px;">
                <a href="..\Subject\subjects.php">Subject Stream</a>
            </li>
            <li style="display: inline; margin-right: 20px;">
                <a href="..\Time Table\time.php">Time Table</a>
            </li>
            <li style="display: inline; margin-right: 20px;">
                <a href="..\About\about.html">About</a>
            </li>
            <li style="display: inline; margin-right: 20px;">
                <a href="contact.php">Contact</a>
            </li>
        </ul>
    </div>
    <div id="timmer">
                <div class="alltime">
                    <div id="hours">00</div>
                </div>
                <div class="alltime">
                    <div id="minutes">00</div>
                </div>
                <div class="alltime">
                    <div id="seconds">00</div>
                </div>
                <div class="disampm">
                    <div id="ampm">AM</div>
                </div>
            </div>
        </div>
</header>

    <section class="contact-section">
        <div class="contact-info">
            <h2>Contact Us</h2>
            <p><strong>Contact Number</strong></p>
            <p>+94 11 22 82 654</p>
            <p>+94 70 22 82 654</p>

            <p><strong>Email</strong></p>
            <p>contact@ozone.edu</p>

            <p><strong>Address</strong></p>
            <p>120/2 Senanayaka St, Borella</p>
        </div>
        <div class="vertical-line"></div>

        <div class="contact-form">
            <form method="POST">
                <label for="name">Enter Your Name</label>
                <input type="text" id="name" name="name" placeholder="Name" required>

                <label for="mobile">Enter Your Mobile Number</label>
                <input type="text" id="email" name="mobile" placeholder="Mobilr Number" required>

                <label for="message">Message</label>
                <textarea id="message" name="message" placeholder="Your message here..." required></textarea>

                <button type="submit" name="submit">Send</button>
            </form>
        </div>
    </section>
    <section class="contact-section">
        <h2>Contact List</h2>
                <table class="styled-table" border="1">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Mobile</th>
                            <th>Message</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php 
                        // Fetch data from 'book' table and display in the table rows
                        $query = "SELECT * FROM `contact`";
                        $result = mysqli_query($con, $query);
                        while($row = mysqli_fetch_assoc($result)){
                    ?>
                        <tr>
                            <td><?php echo $row['id'] ?></td>
                            <td><?php echo $row['name'] ?></td>
                            <td><?php echo $row['mobile'] ?></td>
                            <td><?php echo $row['message'] ?></td>
                            <td>
                                <a href="update.php?updateid=<?php echo $row['id']; ?>"><button class="btn">Edit</button></a>
                                <a href="delete.php?deleteid=<?php echo $row['id']; ?>"><button class="btn">Delete</button></a>
                            </td>
                        </tr>
                    <?php
                        }
                    ?>
                    </tbody>
                </table>
    </section>

    <footer>
        <p>Copyright © 2024 Website. All rights reserved.</p>
    </footer>
    <script type="text/javascript">
        setInterval(() => {
    let hours = document.getElementById('hours');
    let minutes = document.getElementById('minutes');
    let seconds = document.getElementById('seconds');
    let ampm = document.getElementById('ampm');

    let h = new Date().getHours();
    let m = new Date().getMinutes();
    let s = new Date().getSeconds();
    let am = (h >= 12) ? "PM" : "AM";

    if (h > 12) {
        h = h - 12;
    }

    h = (h < 10) ? "0" + h : h;
    m = (m < 10) ? "0" + m : m;
    s = (s < 10) ? "0" + s : s;

    hours.innerHTML = h;
    minutes.innerHTML = m;
    seconds.innerHTML = s;
    ampm.innerHTML = am;

})
    </script>
</body>
</html>