<?php
include 'connect.php';

$id = $_GET['updateid'];
$sql = "SELECT * FROM `contact` WHERE id=$id";
$result = mysqli_query($con, $sql);
$row = mysqli_fetch_assoc($result);
$name = $row['name'];
$mobile = $row['mobile'];
$message = $row['message'];

if (isset($_POST['submit'])) {
    $name = mysqli_real_escape_string($con, $_POST['name']);
    $mobile = mysqli_real_escape_string($con, $_POST['mobile']);
    $message = mysqli_real_escape_string($con, $_POST['message']);

    // Corrected SQL query to update the right table
    $sql = "UPDATE `contact` SET 
                name='$name', 
                mobile='$mobile', 
                message='$message' 
            WHERE id=$id";
    
    $result = mysqli_query($con, $sql);

    if ($result) {
        header('Location: Contact.php');
    } else {
        die(mysqli_error($con));
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crud oparation</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="navbar">
            <div class="logo">Horaizon International Education</div>
            <div class="nav-links">
                <a href="#">Home</a>
                <a href="#">Contact</a>
                <a href="#">About</a>
            </div>
            <div class="profile-icon">
                <img src="profile-placeholder.png" alt="Profile Icon">
            </div>
        </div>
    </header>   
<section class="contact-section">
        <div class="contact-info">
            <h2>Contact Us</h2>
            <p><strong>Contact Number</strong></p>
            <p>+94 11 22 82 654</p>
            <p>+94 70 22 82 654</p>

            <p><strong>Address</strong></p>
            <p>123 Street Name, City, Country</p>
        </div>
        <div class="vr"></div>

        <div class="contact-form">
            <form action="#" method="POST">
                <label for="name">Enter Your Name</label>
                <input type="text" id="name" name="name" value="<?php echo $name?>" placeholder="Name" required>

                <label for="mobile">Enter Your Mobile Number</label>
                <input type="text" id="email" name="mobile" value="<?php echo $mobile?>" placeholder="Mobilr Number" required>

                <label for="message">Message</label>
                <textarea id="message" name="message" value="<?php echo $message?>"><?php echo $message?></textarea>

                <button type="submit" name="submit">Update</button>
            </form>
        </div>
    </section>
    <footer>
        <p>Copyright © 2024 Website. All rights reserved.</p>
    </footer>

</body>
</html>