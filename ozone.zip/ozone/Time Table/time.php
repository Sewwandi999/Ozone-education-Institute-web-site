<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ozone Institute</title>
    <style>
	body {
			box-sizing: border-box;
  
    .header .container {
      display: flex;
      align-items: center; 
      background-color: black;

    }

    .header .container button{
      margin-left: 100px;
      width: 15%;
      padding: 10px;
      background-color:rgba(0, 0, 0, 0.9);
      color: #39d5ff;
      border: 2px solid #39d5ff;
      font-size: 18px;
      font-weight: bold;
    }
    .header .container button:hover{
      color: darkgray;
    }


    .header .container .logo {
      margin-right: 20px; 
    }


    .header .container p {
      margin: 0;
      font-size: 1.5rem; 
      font-weight: bold;
      color: #39d5ff;
      font-size: 80px; 
      text-align: center;
      margin-left: 25px;
  }


    .navbar{
      justify-content: space-between;
      background-color: black; 
      border-bottom: 5px solid #39d5ff; 
      border-top: 1px solid #39d5ff;
      align-content: center;
  }
  
    .container, .navbar {
            margin: 0px;
            padding: 0px;
            color: white;
            font-weight: bold;
            font-size: 20px;
        }
    .navbar li a{
    text-decoration: none;
    color: #39d5ff; 
    font-weight: bold;
    padding: 5px 10px;
    transition: color 0.3s ease;
    border-right: 1px solid #39d5ff;
    border-left: 1px solid #39d5ff;
  }
    .navbar li a:hover {
      color: darkred; 
  }
		h1{
			color: white;
			padding: 20px;
			text-align: center;
			font-size: 26px;
			border-radius: 10px;
			box-shadow: 10px 10px 10px rgba(0, 0, 0, 0.1);
			font-family: 'Times new roman';
			color: #38ACEC;
			text-align: center;
		}
		h2 {
            font-size: 24px;
            color: darkslategray;
            margin-top: 10px;
            margin-bottom: 30px;
			text-align: center;
        }
		
        table {
            width: 100%;
			margin: 30px auto;
			border-collapse: collapse;
			background-color: white;
			box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
		
         th {
        padding: 15px;
        text-align: center;
        border: 1px solid #ddd;
        background-color: #F0FFFF;
        color: white;
        font-size: 18px;
		color: #25383C;
		}
		
		td {
        padding: 15px;
        text-align: center;
        border: 1px solid #ddd;
        background-color: #f9f9f9;
        font-size: 18px;
			
        }
		
		.timetable {
            opacity: 0;
            transform: translateY(50px);
            transition: opacity 0.8s ease-out, transform 0.8s ease-out;
        }

        .timetable.show {
            opacity: 1;
            transform: translateY(0);
        }
		
		.login-container {
		background-color: black;
		padding: 20px;
		border-radius: 8px;
		box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
		width: 300px;
		text-align: center;
		}

		
		
		.login-container h2 {
			margin-bottom: 20px;
			color: #39d5ff;
			font-size: 40px;
			margin-top: 0px;
		}


		.input-group {
			margin-bottom: 15px;
			text-align: left;
		}

		.input-group label {
			display: block;
			margin-bottom: 5px;
			color: white;
			font-weight: bold;
		}

		.input-group input {
			color: white;
			width: 100%;
			padding: 8px;
			border-radius: 4px;
			border: 2px solid #ddd;
			box-sizing: border-box;
			font-size: 14px;
			background-color: transparent;
		}

		.btn {
			width: 100%;
			padding: 10px;
			background-color: #007bff;
			color: #fff;
			border: none;
			border-radius: 4px;
			font-size: 16px;
			cursor: pointer;
		}

		.btn:hover {
			background-color: #0056b3;
		}


		.error-message {
			color: red;
			margin-top: 10px;
			display: none;
		}
	}
		
    </style>
</head>
<body>
	<header class="header" data-header>
    <div class="container">
        <a href="#" class="logo">
            <img src="..\Home\images\Black and Blue Initials Creative Logo (2).png" width="200" height="200" alt="logo">
        </a>
        <p>Ozone Education Institute</p>
        
        
        <?php if (isset($_SESSION['username'])): ?>
    <button onclick="window.location.href='logout.php'">
        <img src="graduating-student.png" width="25" height="25"> <?php echo htmlspecialchars($_SESSION['username']); ?>/Logout
    </button>
<?php else: ?>
    <button onclick="window.location.href='login.html'">
        <img src="graduating-student.png" width="30" height="30"> Log in
    </button>
<?php endif; ?>

        
    </div>

    <div class="navbar">
        <ul style="list-style-type: none; padding: 0; text-align: center;">
            <li style="display: inline; margin-right: 20px; color: red;">
                <a href="..\Home\home.php">Home</a>
            </li>
            
            <li style="display: inline; margin-right: 20px;">
                <a href="..\Subject\subjects.php">Subject Stream</a>
            </li>
            <li style="display: inline; margin-right: 20px;">
                <a href="time.php">Time Table</a>
            </li>
            <li style="display: inline; margin-right: 20px;">
                <a href="..\About\about.html">About</a>
            </li>
            <li style="display: inline; margin-right: 20px;">
                <a href="..\Contact\Contact.php">Contact</a>
            </li>
        </ul>
    </div>
</header>
  
  <div id="science-timetable" class="timetable">
    <h1>Science Stream</h1>
	
    <table>
        <tr>
            <th>Subject</th>
			<th>Name</th>
            <th>Teacher</th>
            <th>Day</th>
            <th>From</th>
			 <th>To</th>
        </tr>
        <tr>
            <td>Bio Science</td>
			<td>2021 Theory</td>
            <td>Pudubu Senanayaka</td>
            <td>Sunday</td>
			<td>10:00 AM</td> 
			<td>12:00 PM</td>
        </tr>
        <tr>
            <td>Bio Science</td>
			<td>2022 Theory</td>
            <td>Pudubu Senanayaka</td>
            <td>Sunday</td>
			<td>12:30PM</td> 
			<td>2:30 PM</td>
        </tr>
		 <tr>
            <td>Bio Science</td>
			<td>2021 Revesion </td>
            <td>Pudubu Senanayaka</td>
            <td>Monday</td>
			<td>8:00 AM</td> 
			<td>4:00 PM</td>
        </tr>
		 <tr>
            <td>Bio Science</td>
			<td>2022 Revesion </td>
            <td>Pudubu Senanayaka</td>
            <td>Tuesday</td>
			<td>8:00 AM</td> 
			<td>4:00 PM</td>
        </tr>
		<tr>
            <td>Com.Maths</td>
			<td>2021 Theory</td>
            <td>Dinesh Muthugala</td>
            <td>Sunday</td>
			<td>10:00 AM</td> 
			<td>12:00 PM</td>
        </tr>
		<tr>
            <td>Com.Maths</td>
			<td>2022 Theory</td>
            <td>Dinesh Muthugala</td>
            <td>Sunday</td>
			<td>12.30 PM</td> 
			<td>2:30 PM</td>
        </tr>
		<tr>
            <td>Com.Maths</td>
			<td>2021 Revesion</td>
            <td>Dinesh Muthugala</td>
            <td>Monday</td>
			<td>8:00 AM</td> 
			<td>4:00 PM</td>
        </tr>
		<tr>
            <td>Com.Maths</td>
			<td>2022 Revesion </td>
            <td>Dinesh Muthugala</td>
            <td>Tuesday</td>
			<td>8:00 AM</td> 
			<td>4:00 PM</td>
        </tr>
		<tr>
            <td>Physics</td>
			<td>2021 Theory</td>
            <td>Chandana Mendis</td>
            <td>Sunday</td>
			<td>12.30 PM</td> 
			<td>2:30 PM</td>
        </tr>
		<tr>
            <td>Physics</td>
			<td>2021 Revesion</td>
            <td>Chandana Mendis</td>
            <td>Tuesday</td>
			<td>8:00 AM</td> 
			<td>4:00 PM</td>
        </tr>
		<tr>
            <td>Physics</td>
			<td>2022 Revesion</td>
            <td>Chandana Mendis</td>
            <td>Monday</td>
			<td>8:00 AM</td> 
			<td>4:00 PM</td>
        </tr>
		<tr>
            <td>Chemistry</td>
			<td>2021 Theory</td>
            <td>Sanath Nishantha</td>
            <td>Sunday</td>
			<td>3.00 PM</td> 
			<td>5.00 PM</td>
        </tr>
		<tr>
            <td>Chemistry</td>
			<td>2022 Theory</td>
            <td>Sanath Nishantha</td>
            <td>Saturday</td>
			<td>3.00 PM</td> 
			<td>5.00 PM</td>
        </tr>
		<tr>
            <td>Chemistry</td>
			<td>2021 Revesion</td>
            <td>Sanath Nishantha</td>
            <td>Thursday</td>
			<td>8:00 AM</td> 
			<td>4:00 PM</td>
        </tr>
		<tr>
            <td>Chemistry</td>
			<td>2022 Revesion</td>
            <td>Sanath Nishantha</td>
            <td>Friday</td>
			<td>8:00 AM</td> 
			<td>4:00 PM</td>
        </tr>
		<tr>
            <td>IT</td>
			<td>2021 Theory</td>
            <td>Supun Piyumal</td>
            <td>Sunday</td>
			<td>3.00 PM</td> 
			<td>5.00 PM</td>
        </tr>
		<tr>
            <td>IT</td>
			<td>2022 Theory</td>
            <td>Supun Piyumal</td>
            <td>Saturday</td>
			<td>3.00 PM</td> 
			<td>5.00 PM</td>
        </tr>
		<tr>
            <td>IT</td>
			<td>2021 Revesion</td>
            <td>Supun Piyumal</td>
            <td>Thursday</td>
			<td>8:00 AM</td> 
			<td>4:00 PM</td>
        </tr>
		<tr>
            <td>IT</td>
			<td>2022 Revesion</td>
            <td>Spun Piyumal</td>
            <td>Friday</td>
			<td>8:00 AM</td> 
			<td>4:00 PM</td>
        </tr>
    </table>
</div>

<div id="technology-timetable" class="timetable">
    <h1>Technology Stream</h1>
    <table>
      <tr>
        <th>Subject</th>
		<th>Name</th>
        <th>Teacher</th>
        <th>Day</th>
        <th>From</th>
		<th>To</th>
      </tr>
		<tr>
            <td>Bio Tech</td>
			<td>2021 Theory</td>
            <td>Suneth Athauda</td>
            <td>Sunday</td>
			<td>10:00 AM</td> 
			<td>12:00 PM</td>
        </tr>
		 <tr>
            <td>Bio Tech</td>
			<td>2022 Theory</td>
            <td>Suneth Athauda</td>
            <td>Sunday</td>
			<td>12:30PM</td> 
			<td>2:30 PM</td>
        </tr>
		<tr>
            <td>Bio Tech</td>
			<td>2021 Revesion</td>
            <td>Suneth Athauda</td>
            <td>Monday</td>
			<td>8:00 AM</td> 
			<td>4:00 PM</td>
        </tr>
		<tr>
            <td>Bio Tech</td>
			<td>2022 Revesion </td>
            <td>Suneth Athauda</td>
            <td>Tuesday</td>
			<td>8:00 AM</td> 
			<td>4:00 PM</td>
		<tr>
		<tr>
            <td>E-Tech</td>
			<td>2021 Theory</td>
            <td>Suneth Athauda</td>
            <td>Sunday</td>
			<td>10:00 AM</td> 
			<td>12:00 PM</td>
        </tr>
		<tr>
            <td>E-Tech</td>
			<td>2022 Theory</td>
            <td>Suneth Athauda</td>
            <td>Sunday</td>
			<td>12.30 PM</td> 
			<td>2:30 PM</td>
        </tr>
		<tr>
            <td>E-Tech</td>
			<td>2021 Revesion</td>
            <td>Suneth Athauda</td>
            <td>Monday</td>
			<td>8:00 AM</td> 
			<td>4:00 PM</td>
        </tr>
		<tr>
            <td>E-Tech</td>
			<td>2022 Revesion </td>
            <td>Suneth Athauda</td>
            <td>Tuesday</td>
			<td>8:00 AM</td> 
			<td>4:00 PM</td>
        </tr>
		<tr>
            <td>SFT</td>
			<td>2021 Theory</td>
            <td>Kamal Addaraarachchi</td>
            <td>Sunday</td>
			<td>3.00 PM</td> 
			<td>5.00 PM</td>
        </tr>
		<tr>
            <td>SFT</td>
			<td>2022 Theory</td>
            <td>Kamal Addaraarachchi</td>
            <td>Saturday</td>
			<td>3.00 PM</td> 
			<td>5.00 PM</td>
        </tr>
		<tr>
            <td>SFT</td>
			<td>2021 Revesion</td>
            <td>Kamal Addaraarachchi</td>
            <td>Thursday</td>
			<td>8:00 AM</td> 
			<td>4:00 PM</td>
        </tr>
		<tr>
            <td>SFT</td>
			<td>2022 Revesion</td>
            <td>Kamal Addaraarachchi</td>
            <td>Friday</td>
			<td>8:00 AM</td> 
			<td>4:00 PM</td>
        </tr>
		<tr>
            <td>IT</td>
			<td>2021 Theory</td>
            <td>Supun Piyumal</td>
            <td>Sunday</td>
			<td>3.00 PM</td> 
			<td>5.00 PM</td>
        </tr>
		<tr>
            <td>IT</td>
			<td>2022 Theory</td>
            <td>Supun Piyumal</td>
            <td>Saturday</td>
			<td>3.00 PM</td> 
			<td>5.00 PM</td>
        </tr>
		<tr>
            <td>IT</td>
			<td>2021 Revesion</td>
            <td>Supun Piyumal</td>
            <td>Thursday</td>
			<td>8:00 AM</td> 
			<td>4:00 PM</td>
        </tr>
		<tr>
            <td>IT</td>
			<td>2022 Revesion</td>
            <td>Spun Piyumal</td>
            <td>Friday</td>
			<td>8:00 AM</td> 
			<td>4:00 PM</td>
        </tr>
    </table>
  </div>
  
  <script>
    function revealOnScroll() {
        var timetables = document.querySelectorAll('.timetable');

        for (var i = 0; i < timetables.length; i++) {
            var windowHeight = window.innerHeight;
            var elementTop = timetables[i].getBoundingClientRect().top;
            var elementVisible = 150;

            if (elementTop < windowHeight - elementVisible) {
                timetables[i].classList.add('show');
            }
        }
    }

    
    window.addEventListener('scroll', revealOnScroll);

   
    revealOnScroll();
  </script>
</body>
</html>
